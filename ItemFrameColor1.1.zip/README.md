![Item Frame Color](http://mapmaking.fr/datapack/image/soulshard.png)

### Wiki
[Check out the wiki](https://github.com/kikipunk/Item-Frame-Color-DataPack/wiki)

### Installation 
[Instructions](https://github.com/kikipunk/Item-Frame-Color-DataPack/wiki/Installation)

### Downloads
Now on curseforge! [https://minecraft.curseforge.com/projects/soulshard-datapack](https://minecraft.curseforge.com/projects/soulshard-datapack)

### Credit
By Kikipunk and Daminator4113
